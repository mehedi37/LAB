    // cout << "Enter how many numbers : "<< endl;
    // cin >> n;
    // ofstream out;
    // out.open("search_i.txt");
    // srand(time(nullptr));
    // for (int i{0}; i < n; i++) {
    //     out << rand() << endl;
    // }
    // out.close();