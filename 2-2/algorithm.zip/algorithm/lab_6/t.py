from collections import defaultdict

# Parse the input
input_lines = [
    "S A 10",
    "S B 3",
    "A C 10",
    "B C 5",
    "B D 7",
    "C E 5",
    "B D 7",
    "C D 6",
    "E D 12",
    "E F 4",
    "D F 5",
]

# Create a dictionary where each key is a node and the value is a list of tuples,
# each containing a connected node and the weight of the connection
graph = defaultdict(list)
for line in input_lines:
    node1, node2, weight = line.split()
    graph[node1].append((node2, int(weight)))

# Create a list of all nodes
nodes = sorted(set(node for node in graph.keys() for node in graph[node]))

# Create the adjacency matrix
matrix = [[0 for _ in nodes] for _ in nodes]
for node1, connections in graph.items():
    for node2, weight in connections:
        matrix[nodes.index(node1)][nodes.index(node2)] = weight

# Print the adjacency matrix
for row in matrix:
    print(row)