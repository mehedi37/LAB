#include<bits/stdc++.h>
using namespace std;

int main() {
    int n;
    int x[100], y[100];
    cout<< "\nCalculates the best fit value using least square method in y = a + bx.\n";
    cout<< "\nEnter number of data pairs:\n";
    cin >> n;
    cout << "\n\nEnter value pair:\n" << endl;

    for (int i = 0; i < n; i++) {
        cout <<"      Data " << i + 1 << " :\n";
        cout <<"x: ";
        cin >> x[i];
        cout << x[i] << endl;
        cout << "y: ";
        cin >> y[i];
        cout << y[i] << endl;
    }
    cout << "\n\nData input completed." << endl;

    float sumy = 0, sumx = 0, sumxy = 0, sumxx = 0;
    for (int i = 0; i < n; i++) {
        sumy += y[i];
        sumx += x[i];
        sumxy += y[i] * x[i];
        sumxx += x[i] * x[i];
    }

    cout << "\n\nx      y       x^2     xy\n";
    cout << "__________________________\n" << endl;
    for (int i = 0; i < n; i++) {
        cout << x[i] << "      " << setw(1) << y[i] << "      " << setw(1) << x[i] * x[i] << "      "
                << setw(2) << x[i] * y[i] << endl;
    }

    cout << "\n\nThe calculated value of sumx, sumy, sumxx, sumxy is : \n" << sumx << ", "
        << sumy << ", " << sumxx << ", " << sumxy << "." << endl;
    float a = (sumx * sumxy - sumy * sumxx) / (float)(sumx * sumx - n * sumxx);
    float b = (sumy * sumx - n * sumxy) / (float)(sumx * sumx - n*sumxx);

    cout << "\n\nThe calculated value of a and b is : \n" << a << " and " << b << "." << endl;
    cout << "\n\nThe best fit value of curve is : y = "<< a << " + " << b << "x.\n\n" << endl;
}

// 0 -1
// 2 5
// 5 12
// 7 20